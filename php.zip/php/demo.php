<!DOCTYPE html>
<html>
    <body>
        
    <?php
    echo "my first php";
    
    </body>
</html>